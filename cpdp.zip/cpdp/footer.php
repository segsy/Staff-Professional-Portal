
<!-- Vendor scripts -->
<script src="vendor/jquery/dist/jquery.min.js"></script>
<script src="vendor/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="vendor/metisMenu/dist/metisMenu.min.js"></script>
<script src="vendor/iCheck/icheck.min.js"></script>
<script src="vendor/offcanvas/js/bootstrap.offcanvas.js"></script>
<script src="vendor/mediaelement/mediaelementplayer.min.js"></script>

<!-- App scripts -->


<!-- App scripts -->
<script src="scripts/js.js"></script>

