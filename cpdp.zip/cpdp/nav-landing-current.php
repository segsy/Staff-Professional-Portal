<?php
include("lib/config.php");
include("lib/common.php");
include("lib/function.php");


?>

<!DOCTPE html>
<html>
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- Page title -->
    <title>Continuous Professional Development Portal</title>

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <!--<link rel="shortcut icon" type="image/ico" href="favicon.ico" />-->

    <!-- Vendor styles -->
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.css" />
    <link rel="stylesheet" href="vendor/metisMenu/dist/metisMenu.css" />
    <link rel="stylesheet" href="vendor/animate.css/animate.css" />
    <link rel="stylesheet" href="vendor/bootstrap/dist/css/bootstrap.css" />

    <!-- App styles -->
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/pe-icon-7-stroke.css" />
    <link rel="stylesheet" href="fonts/pe-icon-7-stroke/css/helper.css" />
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="styles/reset.css">
     <link rel="stylesheet" href="vendor/sweetalert/lib/sweet-alert.css" />
     <link rel="stylesheet" href="vendor/ladda/dist/ladda-themeless.min.css" />

</head>
<body class="landing-page signin-page">

<!-- Simple splash screen
<div class="splash"> <div class="splash-title"><h1>Ask The President</h1><p>Get answers to your questions! </p><div class="spinner"> <div class="rect1"></div> <div class="rect2"></div> <div class="rect3"></div> <div class="rect4"></div> <div class="rect5"></div> </div> </div> </div>
-->
<!--[if lt IE 7]>
<p class="alert alert-danger">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
<![endif]-->

<nav class="navbar navbar-default navbar-fixed-top">
    <div class="container">
        <div class="navbar-header">
            <button aria-controls="navbar" aria-expanded="false" data-target="#navbar" data-toggle="collapse" class="navbar-toggle collapsed" type="button">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a href="#" class="navbar-brand"> 
                <span> <i class="pe pe-7s-study"></i>  Continuous Professional Development Portal</span>

            </a><!--
            <div class="brand-desc">
                   <span>Continuous Professional Development Program</span>
             Text groups, from anywhere instantly!
            </div>
            -->
        </div>
        <div id="navbar" class="navbar-collapse collapse">
        <div class="pull-right col-md-9 col-sm-12">
            <ul class="nav navbar-nav">
               <!-- <li><a href="components.php">Home</a></li>
                <li><a href="whyask.php">Why Ask?</a></li> 
                <li><a href="faq.php">Frequently Ask Questions </a></li>-->
            </ul>

          <ul class="nav navbar-nav navbar-acc navbar-right">
                <!-- <li><a href="login.php">Login </a></li>
               <li><a href="register.php">Register </a></li> -->
            </ul>
        </div>
    </div>
    </div>
</nav>

